import { NextRequest,NextResponse } from "next/server";
export const runtime="nodejs";
export async function POST(req:NextRequest){
 try{
  const {prompt,model="Qwen/Qwen2.5-7B-Instruct"}=await req.json();
  if(typeof prompt!=="string"||!prompt.trim()||prompt.length>12000)return NextResponse.json({error:"Enter a prompt under 12,000 characters."},{status:400});
  if(process.env.HF_TOKEN){
   const response=await fetch("https://router.huggingface.co/v1/chat/completions",{method:"POST",headers:{"Authorization":`Bearer ${process.env.HF_TOKEN}`,"Content-Type":"application/json"},body:JSON.stringify({model,messages:[{role:"user",content:prompt}],max_tokens:1200,temperature:0.7})});
   const data=await response.json();if(!response.ok)return NextResponse.json({error:data?.error||"Hugging Face inference request failed."},{status:response.status});
   return NextResponse.json({text:data.choices?.[0]?.message?.content??"The model returned no text."});
  }
  if(process.env.OLLAMA_BASE_URL){
   const response=await fetch(`${process.env.OLLAMA_BASE_URL.replace(/\/$/,"")}/api/chat`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"qwen2.5:7b",messages:[{role:"user",content:prompt}],stream:false})});
   const data=await response.json();if(!response.ok)return NextResponse.json({error:data.error||"Ollama request failed."},{status:response.status});
   return NextResponse.json({text:data.message?.content||"No response from local model."});
  }
  return NextResponse.json({error:"AI is not configured. Add HF_TOKEN in your deployment environment, or configure OLLAMA_BASE_URL for a local Ollama server."},{status:503});
 }catch{return NextResponse.json({error:"Invalid request or AI provider unavailable."},{status:500});}
}