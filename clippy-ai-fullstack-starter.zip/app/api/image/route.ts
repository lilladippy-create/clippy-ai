import { NextRequest,NextResponse } from "next/server";
import { InferenceClient } from "@huggingface/inference";
export const runtime="nodejs";
export async function POST(req:NextRequest){
 try{
  if(!process.env.HF_TOKEN)return NextResponse.json({error:"Add HF_TOKEN to enable image generation."},{status:503});
  const {prompt}=await req.json();if(typeof prompt!=="string"||!prompt.trim()||prompt.length>3000)return NextResponse.json({error:"Enter an image prompt under 3,000 characters."},{status:400});
  const client=new InferenceClient(process.env.HF_TOKEN);
  const blob=await client.textToImage({model:"black-forest-labs/FLUX.1-schnell",inputs:prompt});
  return new NextResponse(blob,{headers:{"Content-Type":blob.type||"image/png","Cache-Control":"no-store"}});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Image provider unavailable."},{status:502});}
}