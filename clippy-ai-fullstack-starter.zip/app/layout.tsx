import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title:"CliPpY AI — Your Creative AI Universe", description:"Chat, write and create with open AI models." };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }