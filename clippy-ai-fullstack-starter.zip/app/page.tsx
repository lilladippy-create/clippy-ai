import { createClient } from "@/lib/supabase/server";
import Workspace from "@/components/Workspace";
export default async function Home(){
 let user=null;
 if(process.env.NEXT_PUBLIC_SUPABASE_URL&&process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY){const supabase=await createClient();const {data}=await supabase.auth.getUser();user=data.user;}
 return <Workspace user={user?{email:user.email??"Signed in"}:null}/>;
}