# CliPpY AI — full-stack starter

A Next.js full-stack application with:
- Responsive CliPpY workspace UI
- Real chat/text generation through Hugging Face Inference Providers
- Image generation through Hugging Face Inference Providers
- Optional local Ollama chat fallback
- Supabase email/password authentication
- Supabase conversation table with row-level security starter schema

## Important: no provider is automatically free
Open-weight models are not the same as free hosted compute. Hugging Face Inference Providers may offer limited credits or charge by usage depending on account, model and provider. For local inference, run Ollama on a machine you control; it requires suitable hardware. Never put API tokens in browser code.

## 1. Install
Requires Node.js 20.9+.
```bash
npm install
cp .env.example .env.local
npm run dev
```
Open http://localhost:3000.

## 2. Enable real AI
Create a Hugging Face token with inference permissions at https://huggingface.co/settings/tokens and put it in `.env.local`:
```env
HF_TOKEN=hf_your_token_here
```
The chat route uses the Hugging Face OpenAI-compatible router. The image route uses the Hugging Face JavaScript Inference Client. Model/provider availability, account credits and licensing vary. See https://huggingface.co/docs/inference-providers.

For local chat instead, install Ollama, pull a model such as `qwen2.5:7b`, start Ollama, then set:
```env
OLLAMA_BASE_URL=http://localhost:11434
```
The server route currently selects `qwen2.5:7b` for Ollama. Do not expose an Ollama server directly to the public internet without authentication and network controls.

## 3. Enable accounts
Create a Supabase project at https://database.new. In Project Settings / API, copy the Project URL and publishable key into `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
```
Run `supabase/schema.sql` in the Supabase SQL Editor. Configure your Auth email settings and add your local and production URLs to the allowed redirect URLs. The app has `/auth` sign-up/sign-in UI.

## 4. Deploy
Push this folder to a private GitHub repository, import it into Vercel, and add the environment variables in Project Settings → Environment Variables. Deploy. Add the production URL to Supabase Auth redirect settings. See https://vercel.com/docs/frameworks/full-stack/nextjs.

## Production work still recommended
Before opening registration to the public, add per-user rate limits and quotas, abuse prevention/CAPTCHA, billing/webhooks, usage metering, conversation persistence UI, email verification/password reset flows, monitoring, and privacy/terms pages. Image generation may need a separate provider or paid capacity. Video generation is not implemented in this starter; add a dedicated video inference provider and job queue rather than pretending text generation creates video.
